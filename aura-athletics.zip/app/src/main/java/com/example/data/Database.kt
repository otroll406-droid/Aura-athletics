package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// -------------------------------------------------------------
// ENTITIES
// -------------------------------------------------------------

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val weightKg: Double = 75.0,
    val heightCm: Double = 175.0,
    val age: Int = 25,
    val gender: String = "Male", // "Male" / "Female"
    val activityLevel: String = "Moderately Active", // "Sedentary" / "Lightly Active" / "Moderately Active" / "Active" / "Very Active"
    val goal: String = "Maintenance" // "Bulk" / "Cut" / "Maintenance"
)

@Entity(tableName = "daily_logs")
data class DailyLog(
    @PrimaryKey val date: String, // YYYY-MM-DD
    val waterMl: Int = 0,
    val creatineTaken: Boolean = false
)

@Entity(tableName = "performance_logs")
data class PerformanceLog(
    @PrimaryKey val date: String, // YYYY-MM-DD
    val bench1RM: Double = 60.0,
    val squat1RM: Double = 80.0,
    val deadlift1RM: Double = 100.0,
    val sprintTime: Double = 4.8, // seconds
    val verticalJump: Double = 45.0 // cm
)

// -------------------------------------------------------------
// DAO
// -------------------------------------------------------------

@Dao
interface FitnessDao {
    // User Profile
    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun getUserProfileFlow(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile WHERE id = 1")
    suspend fun getUserProfile(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserProfile(profile: UserProfile)

    // Daily Habits Logs
    @Query("SELECT * FROM daily_logs ORDER BY date DESC")
    fun getAllDailyLogs(): Flow<List<DailyLog>>

    @Query("SELECT * FROM daily_logs WHERE date = :date")
    suspend fun getDailyLog(date: String): DailyLog?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveDailyLog(log: DailyLog)

    // Performance Lifts & Speed Logs
    @Query("SELECT * FROM performance_logs ORDER BY date DESC")
    fun getAllPerformanceLogs(): Flow<List<PerformanceLog>>

    @Query("SELECT * FROM performance_logs WHERE date = :date")
    suspend fun getPerformanceLog(date: String): PerformanceLog?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePerformanceLog(log: PerformanceLog)
}

// -------------------------------------------------------------
// DATABASE
// -------------------------------------------------------------

@Database(
    entities = [UserProfile::class, DailyLog::class, PerformanceLog::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun fitnessDao(): FitnessDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "aura_fitness_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// -------------------------------------------------------------
// REPOSITORY
// -------------------------------------------------------------

class FitnessRepository(private val dao: FitnessDao) {
    val userProfile: Flow<UserProfile?> = dao.getUserProfileFlow()
    val allDailyLogs: Flow<List<DailyLog>> = dao.getAllDailyLogs()
    val allPerformanceLogs: Flow<List<PerformanceLog>> = dao.getAllPerformanceLogs()

    suspend fun getOrInitProfile(): UserProfile {
        return dao.getUserProfile() ?: UserProfile().also {
            dao.saveUserProfile(it)
        }
    }

    suspend fun saveProfile(profile: UserProfile) {
        dao.saveUserProfile(profile)
    }

    suspend fun getOrInitDailyLog(date: String): DailyLog {
        return dao.getDailyLog(date) ?: DailyLog(date = date).also {
            dao.saveDailyLog(it)
        }
    }

    suspend fun saveDailyLog(log: DailyLog) {
        dao.saveDailyLog(log)
    }

    suspend fun getOrInitPerformanceLog(date: String): PerformanceLog {
        return dao.getPerformanceLog(date) ?: PerformanceLog(date = date).also {
            dao.savePerformanceLog(it)
        }
    }

    suspend fun savePerformanceLog(log: PerformanceLog) {
        dao.savePerformanceLog(log)
    }
}
