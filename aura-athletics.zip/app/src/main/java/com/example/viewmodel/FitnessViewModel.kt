package com.example.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class FitnessViewModel(private val repository: FitnessRepository) : ViewModel() {

    // -------------------------------------------------------------
    // DATE MANAGEMENT
    // -------------------------------------------------------------
    private val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    
    private val _selectedDate = MutableStateFlow(sdf.format(Date()))
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    // -------------------------------------------------------------
    // STATE FLOWS
    // -------------------------------------------------------------
    val profile: StateFlow<UserProfile> = repository.userProfile
        .map { it ?: UserProfile() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserProfile())

    val allDailyLogs: StateFlow<List<DailyLog>> = repository.allDailyLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPerformanceLogs: StateFlow<List<PerformanceLog>> = repository.allPerformanceLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Today's specific records
    val dailyLog: StateFlow<DailyLog> = combine(selectedDate, repository.allDailyLogs) { date, logs ->
        logs.find { it.date == date } ?: DailyLog(date = date)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DailyLog(date = sdf.format(Date())))

    val performanceLog: StateFlow<PerformanceLog> = combine(selectedDate, repository.allPerformanceLogs) { date, logs ->
        logs.find { it.date == date } ?: PerformanceLog(date = date)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PerformanceLog(date = sdf.format(Date())))

    // -------------------------------------------------------------
    // INITIALIZATION & MUTATORS
    // -------------------------------------------------------------
    init {
        // Initialize user profile in DB if not exists
        viewModelScope.launch {
            repository.getOrInitProfile()
            val today = sdf.format(Date())
            repository.getOrInitDailyLog(today)
            repository.getOrInitPerformanceLog(today)
        }
    }

    fun selectDate(dateString: String) {
        _selectedDate.value = dateString
        viewModelScope.launch {
            repository.getOrInitDailyLog(dateString)
            repository.getOrInitPerformanceLog(dateString)
        }
    }

    fun updateProfile(
        weight: Double,
        height: Double,
        age: Int,
        gender: String,
        activityLevel: String,
        goal: String
    ) {
        viewModelScope.launch {
            val updated = UserProfile(
                id = 1,
                weightKg = weight,
                heightCm = height,
                age = age,
                gender = gender,
                activityLevel = activityLevel,
                goal = goal
            )
            repository.saveProfile(updated)
        }
    }

    fun updateWater(amountMl: Int) {
        viewModelScope.launch {
            val date = _selectedDate.value
            val currentLog = repository.getOrInitDailyLog(date)
            val updated = currentLog.copy(waterMl = (currentLog.waterMl + amountMl).coerceAtLeast(0))
            repository.saveDailyLog(updated)
        }
    }

    fun resetWater() {
        viewModelScope.launch {
            val date = _selectedDate.value
            val currentLog = repository.getOrInitDailyLog(date)
            val updated = currentLog.copy(waterMl = 0)
            repository.saveDailyLog(updated)
        }
    }

    fun toggleCreatine() {
        viewModelScope.launch {
            val date = _selectedDate.value
            val currentLog = repository.getOrInitDailyLog(date)
            val updated = currentLog.copy(creatineTaken = !currentLog.creatineTaken)
            repository.saveDailyLog(updated)
        }
    }

    fun updateStrengthLifts(bench: Double, squat: Double, deadlift: Double) {
        viewModelScope.launch {
            val date = _selectedDate.value
            val currentLog = repository.getOrInitPerformanceLog(date)
            val updated = currentLog.copy(
                bench1RM = bench.coerceAtLeast(0.0),
                squat1RM = squat.coerceAtLeast(0.0),
                deadlift1RM = deadlift.coerceAtLeast(0.0)
            )
            repository.savePerformanceLog(updated)
        }
    }

    fun updateAthleticsMetrics(sprint: Double, jump: Double) {
        viewModelScope.launch {
            val date = _selectedDate.value
            val currentLog = repository.getOrInitPerformanceLog(date)
            val updated = currentLog.copy(
                sprintTime = sprint.coerceAtLeast(0.0),
                verticalJump = jump.coerceAtLeast(0.0)
            )
            repository.savePerformanceLog(updated)
        }
    }

    // -------------------------------------------------------------
    // COMPLEX ANALYTIC DERIVATIONS (REACTIVE)
    // -------------------------------------------------------------

    // Macro analytics
    val nutritionMetrics = profile.map { user ->
        calculateMacros(user)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MacroResults())

    // Water target
    val waterTargetMl = profile.map { user ->
        calculateWaterTarget(user)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 2500)

    // Creatine stats
    val creatineStats = allDailyLogs.map { logs ->
        calculateCreatineStats(logs)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CreatineStats())

    // Athletic scores
    val athleticEvaluation = combine(profile, performanceLog) { user, perf ->
        evaluateAthletics(user, perf)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AthleticEvaluation())

    // Badges / Achievements
    val achievements = combine(allDailyLogs, allPerformanceLogs, athleticEvaluation) { daily, perf, eval ->
        deriveAchievements(daily, perf, eval)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // -------------------------------------------------------------
    // CALCULATOR FORMULAS
    // -------------------------------------------------------------

    data class MacroResults(
        val dailyCalories: Int = 2000,
        val proteinG: Int = 150,
        val fatG: Int = 75,
        val carbG: Int = 200,
        val proteinRatio: Double = 2.0,
        val fatRatio: Double = 1.0
    )

    private fun calculateMacros(user: UserProfile): MacroResults {
        // Mifflin-St Jeor
        val bmr = if (user.gender.equals("Male", ignoreCase = true)) {
            10 * user.weightKg + 6.25 * user.heightCm - 5 * user.age + 5
        } else {
            10 * user.weightKg + 6.25 * user.heightCm - 5 * user.age - 161
        }

        val multiplier = when (user.activityLevel) {
            "Sedentary" -> 1.2
            "Lightly Active" -> 1.375
            "Moderately Active" -> 1.55
            "Active" -> 1.725
            "Very Active" -> 1.9
            else -> 1.55
        }

        val tdee = bmr * multiplier

        val calories = when (user.goal) {
            "Bulk" -> tdee + 400
            "Cut" -> tdee - 500
            else -> tdee // Maintenance
        }.toInt().coerceAtLeast(1200)

        // Protein setting: Elite athletes
        val proteinRatio = when (user.goal) {
            "Cut" -> 2.2
            "Bulk" -> 2.0
            else -> 1.8
        }
        val proteinG = (user.weightKg * proteinRatio).toInt().coerceAtLeast(40)

        // Fat setting: 1.0g per kg of bodyweight
        val fatRatio = 1.0
        val fatG = (user.weightKg * fatRatio).toInt().coerceAtLeast(30)

        // Carbs: rest of calories
        val proteinCal = proteinG * 4
        val fatCal = fatG * 9
        val remainingCal = (calories - proteinCal - fatCal).coerceAtLeast(0)
        val carbG = remainingCal / 4

        return MacroResults(
            dailyCalories = calories,
            proteinG = proteinG,
            fatG = fatG,
            carbG = carbG,
            proteinRatio = proteinRatio,
            fatRatio = fatRatio
        )
    }

    private fun calculateWaterTarget(user: UserProfile): Int {
        val baseMl = user.weightKg * 35.0 // 35 ml / kg
        val extraMl = when (user.activityLevel) {
            "Sedentary" -> 0.0
            "Lightly Active" -> 250.0
            "Moderately Active" -> 500.0
            "Active" -> 1000.0
            "Very Active" -> 1500.0
            else -> 500.0
        }
        return (baseMl + extraMl).toInt().coerceIn(1500, 6000)
    }

    data class CreatineStats(
        val streak: Int = 0,
        val compliance7Days: Double = 0.0,
        val compliance30Days: Double = 0.0
    )

    private fun calculateCreatineStats(logs: List<DailyLog>): CreatineStats {
        if (logs.isEmpty()) return CreatineStats()

        val sorted = logs.sortedByDescending { it.date }
        val todayStr = sdf.format(Date())
        val cal = Calendar.getInstance()
        
        // Calculate streak starting yesterday or today
        var streak = 0
        var currentCheckDate = Date()
        
        // If yesterday was taken but today not yet, streak continues
        val todayLog = sorted.find { it.date == todayStr }
        val todayTaken = todayLog?.creatineTaken ?: false
        
        cal.time = Date()
        if (!todayTaken) {
            // Check yesterday
            cal.add(Calendar.DAY_OF_YEAR, -1)
            currentCheckDate = cal.time
        }

        var checkedDateStr = sdf.format(currentCheckDate)
        var streakBroken = false
        var iterations = 0
        
        while (!streakBroken && iterations < 365) {
            val log = sorted.find { it.date == checkedDateStr }
            if (log != null && log.creatineTaken) {
                streak++
                cal.time = sdf.parse(checkedDateStr) ?: Date()
                cal.add(Calendar.DAY_OF_YEAR, -1)
                checkedDateStr = sdf.format(cal.time)
            } else {
                streakBroken = true
            }
            iterations++
        }

        // 7-day and 30-day compliance
        var taken7 = 0
        var taken30 = 0
        
        val dateKeys7 = mutableSetOf<String>()
        val dateKeys30 = mutableSetOf<String>()
        
        val c7 = Calendar.getInstance()
        for (i in 0 until 7) {
            dateKeys7.add(sdf.format(c7.time))
            c7.add(Calendar.DAY_OF_YEAR, -1)
        }
        
        val c30 = Calendar.getInstance()
        for (i in 0 until 30) {
            dateKeys30.add(sdf.format(c30.time))
            c30.add(Calendar.DAY_OF_YEAR, -1)
        }

        logs.forEach { log ->
            if (log.creatineTaken) {
                if (dateKeys7.contains(log.date)) taken7++
                if (dateKeys30.contains(log.date)) taken30++
            }
        }

        return CreatineStats(
            streak = if (todayTaken && streak == 0) 1 else streak,
            compliance7Days = (taken7 / 7.0 * 100.0).coerceIn(0.0, 100.0),
            compliance30Days = (taken30 / 30.0 * 100.0).coerceIn(0.0, 100.0)
        )
    }

    data class AthleticEvaluation(
        val relativeBench: Double = 0.8,
        val relativeSquat: Double = 1.0,
        val relativeDeadlift: Double = 1.25,
        val benchLevel: String = "Intermediate",
        val squatLevel: String = "Beginner",
        val deadliftLevel: String = "Intermediate",
        val strengthScore: Double = 40.0,
        
        val peakPowerWatts: Double = 2500.0,
        val explosivePowerScore: Double = 45.0,
        
        val speedPercentile: Double = 50.0,
        
        val jumpIndex: Double = 40.0,
        
        val overallAthleticIndex: Double = 40.0,
        val category: String = "Intermediate"
    )

    private fun evaluateAthletics(user: UserProfile, perf: PerformanceLog): AthleticEvaluation {
        val w = user.weightKg.coerceAtLeast(40.0)

        // 1. STRENGTH STANDARD RATIOS
        val benchRatio = perf.bench1RM / w
        val squatRatio = perf.squat1RM / w
        val deadliftRatio = perf.deadlift1RM / w

        val benchLvl = when {
            benchRatio >= 1.5 -> "Elite"
            benchRatio >= 1.2 -> "Advanced"
            benchRatio >= 0.8 -> "Intermediate"
            else -> "Beginner"
        }
        val squatLvl = when {
            squatRatio >= 2.2 -> "Elite"
            squatRatio >= 1.7 -> "Advanced"
            squatRatio >= 1.2 -> "Intermediate"
            else -> "Beginner"
        }
        val deadliftLvl = when {
            deadliftRatio >= 2.5 -> "Elite"
            deadliftRatio >= 2.0 -> "Advanced"
            deadliftRatio >= 1.4 -> "Intermediate"
            else -> "Beginner"
        }

        // Scores normalized to elite (which corresponds to 100%)
        val benchScore = (benchRatio / 1.5 * 100.0).coerceIn(10.0, 100.0)
        val squatScore = (squatRatio / 2.2 * 100.0).coerceIn(10.0, 100.0)
        val deadliftScore = (deadliftRatio / 2.5 * 100.0).coerceIn(10.0, 100.0)
        val strengthScore = (benchScore + squatScore + deadliftScore) / 3.0

        // 2. EXPLOSIVE POWER (Peak Power via Saylor Formula of vertical jump)
        // Watts = 60.7 * Jump_cm + 45.3 * Weight_kg - 2055
        val peakPower = if (perf.verticalJump > 0) {
            (60.7 * perf.verticalJump + 45.3 * w - 2055.0).coerceAtLeast(0.0)
        } else 0.0

        // Elite vertical jump target: 80cm
        val explosiveScore = (perf.verticalJump / 80.0 * 100.0).coerceIn(0.0, 100.0)

        // 3. SPEED (30m Sprint in seconds)
        // Elite 3.8s, Beginner 5.5s
        val sprintTimeSec = perf.sprintTime.coerceAtLeast(3.0)
        val speedScore = ((5.5 - sprintTimeSec) / (5.5 - 3.8) * 100.0).coerceIn(0.0, 100.0)

        // 4. JUMP PERFORMANCE (Normalized jump height)
        val jumpIdx = (perf.verticalJump / 85.0 * 100.0).coerceIn(0.0, 100.0)

        // 5. COMBINED ATHLETIC SCORE
        // Strength -> 35%
        // Explosive Power -> 25%
        // Speed -> 20%
        // Jump -> 20%
        val totalScore = (strengthScore * 0.35) + (explosiveScore * 0.25) + (speedScore * 0.20) + (jumpIdx * 0.20)

        val classification = when {
            totalScore >= 85.0 -> "Elite"
            totalScore >= 72.0 -> "Athlete"
            totalScore >= 55.0 -> "Advanced"
            totalScore >= 35.0 -> "Intermediate"
            else -> "Beginner"
        }

        return AthleticEvaluation(
            relativeBench = benchRatio,
            relativeSquat = squatRatio,
            relativeDeadlift = deadliftRatio,
            benchLevel = benchLvl,
            squatLevel = squatLvl,
            deadliftLevel = deadliftLvl,
            strengthScore = strengthScore,
            peakPowerWatts = peakPower,
            explosivePowerScore = explosiveScore,
            speedPercentile = speedScore,
            jumpIndex = jumpIdx,
            overallAthleticIndex = totalScore,
            category = classification
        )
    }

    data class Achievement(
        val title: String,
        val description: String,
        val icon: String, // String representation of icon name
        val achieved: Boolean
    )

    private fun deriveAchievements(
        daily: List<DailyLog>,
        perf: List<PerformanceLog>,
        eval: AthleticEvaluation
    ): List<Achievement> {
        val waterStreakDays = daily.filter { it.waterMl >= 2000 }.size
        val hasWaterChamp = waterStreakDays >= 3
        val hasCreatineDed = (allDailyLogs.value.filter { it.creatineTaken }.size) >= 7
        val hasIronAthlete = eval.relativeBench >= 1.0 || eval.relativeSquat >= 1.5
        val hasExplosiveForce = eval.peakPowerWatts > 4000.0 || (perf.firstOrNull()?.verticalJump ?: 0.0) >= 50.0
        val isSpeedDemon = (perf.firstOrNull()?.sprintTime ?: 9.9) <= 4.4
        val isEliteRank = eval.overallAthleticIndex >= 72.0

        return listOf(
            Achievement(
                title = "Water Champion",
                description = "Logged water above 2L for 3 or more days",
                icon = "WaterDrop",
                achieved = hasWaterChamp
            ),
            Achievement(
                title = "Creatine Dedicated",
                description = "Committed to creatine supplementation for at least 7 total days",
                icon = "Bolt",
                achieved = hasCreatineDed
            ),
            Achievement(
                title = "Iron Gladiator",
                description = "Pushed raw physical strength limits (bench press 1x bodyweight)",
                icon = "FitnessCenter",
                achieved = hasIronAthlete
            ),
            Achievement(
                title = "Kinetic Dynamo",
                description = "Exceeded 4000 Watts peak power or a 50cm vertical leap",
                icon = "Autorenew",
                achieved = hasExplosiveForce
            ),
            Achievement(
                title = "Aura Speed Demon",
                description = "Clocked a blazing sprint time under 4.4 seconds",
                icon = "Speed",
                achieved = isSpeedDemon
            ),
            Achievement(
                title = "Peak Performer",
                description = "Achieved the high-tier 'Athlete' or 'Elite' index classification",
                icon = "Star",
                achieved = isEliteRank
            )
        )
    }
}

// -------------------------------------------------------------
// FACTORY
// -------------------------------------------------------------

class FitnessViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FitnessViewModel::class.java)) {
            val database = AppDatabase.getDatabase(context)
            val repository = FitnessRepository(database.fitnessDao())
            @Suppress("UNCHECKED_CAST")
            return FitnessViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
