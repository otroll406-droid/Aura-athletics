package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.FitnessViewModel
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: FitnessViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val date by viewModel.selectedDate.collectAsStateWithLifecycle()
    val eval by viewModel.athleticEvaluation.collectAsStateWithLifecycle()
    val macros by viewModel.nutritionMetrics.collectAsStateWithLifecycle()
    val waterTarget by viewModel.waterTargetMl.collectAsStateWithLifecycle()
    val dailyLog by viewModel.dailyLog.collectAsStateWithLifecycle()
    val crStats by viewModel.creatineStats.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        val parsedDateHeader = remember(date) {
            try {
                val inputFormat = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US)
                val outputFormat = java.text.SimpleDateFormat("EEEE, MMM d", Locale.US)
                val d = inputFormat.parse(date)
                if (d != null) outputFormat.format(d) else date
            } catch (e: Exception) {
                date
            }
        }

        SleekScreenHeader(
            title = "Overview",
            subtitle = parsedDateHeader
        )

        // --- ATHLETIC INDEX GRAPHIC ---
        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1.3f)) {
                    Text(
                        text = "Athletic Index",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Overall biomechanical performance score evaluated across strength, explosiveness, power, and sprint speed.",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = when (eval.category) {
                            "Elite" -> AlertPink.copy(alpha = 0.25f)
                            "Athlete" -> AppleBlue.copy(alpha = 0.25f)
                            "Advanced" -> VoltGreen.copy(alpha = 0.25f)
                            else -> Color(0x22FFFFFF)
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = eval.category.uppercase(),
                            color = when (eval.category) {
                                "Elite" -> AlertPink
                                "Athlete" -> AppleBlue
                                "Advanced" -> VoltGreen
                                else -> Color.White
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            letterSpacing = 1.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Box(
                    modifier = Modifier.weight(0.7f),
                    contentAlignment = Alignment.Center
                ) {
                    AuraCircularRing(
                        progress = (eval.overallAthleticIndex / 100.0).toFloat(),
                        label = "SCORE",
                        valueText = "${eval.overallAthleticIndex.toInt()}%",
                        color = AppleBlue,
                        sizeDp = 110.dp,
                        strokeWidth = 12.dp
                    )
                }
            }
        }

        // --- CALORIES & MACROS GLANCE ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Left calorie card
            AuraGlassCard(modifier = Modifier.weight(1.1f)) {
                Text(
                    text = "Nutrition Target",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${macros.dailyCalories} kcal",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(8.dp))
                // Progress representing carbs
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(6.dp).background(VoltGreen, CircleShape))
                            Text("Protein", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                        }
                        Text("${macros.proteinG}g", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    AuraNeonProgress(progress = 0.75f, color = VoltGreen)

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(6.dp).background(WarmOrange, CircleShape))
                            Text("Carbs", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                        }
                        Text("${macros.carbG}g", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    AuraNeonProgress(progress = 0.6f, color = WarmOrange)
                }
            }

            // Right water card
            AuraGlassCard(modifier = Modifier.weight(0.9f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Hydration",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(
                        imageVector = Icons.Default.WaterDrop,
                        contentDescription = "Water",
                        tint = AppleBlue,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${dailyLog.waterMl} ml",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Goal: $waterTarget ml",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                val waterPercent = (dailyLog.waterMl.toFloat() / waterTarget.toFloat()).coerceIn(0f, 1f)
                AuraNeonProgress(progress = waterPercent, color = AppleBlue, height = 6.dp)
                
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("water_add_button")
                            .clickable { viewModel.updateWater(250) },
                        color = Color(0x22FFFFFF),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "+250",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    }
                    Surface(
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("water_add_large_button")
                            .clickable { viewModel.updateWater(500) },
                        color = Color(0x3DFFFFFF),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "+500",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // --- CREATINE SUPPS TRACKER ---
        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1.1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Creatine",
                            tint = WarmOrange,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Creatine Tracker",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "5g daily. Saturates muscle cells to fuel explosive ATP pathways.",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 11.sp,
                        lineHeight = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Column {
                            Text(
                                text = "${crStats.streak} Days",
                                color = WarmOrange,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Current Streak",
                                color = Color.White.copy(alpha = 0.4f),
                                fontSize = 10.sp
                            )
                        }
                        Column {
                            Text(
                                text = "${crStats.compliance7Days.toInt()}%",
                                color = VoltGreen,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "7-Day Rate",
                                color = Color.White.copy(alpha = 0.4f),
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Toggle taken button
                val takenColor = if (dailyLog.creatineTaken) VoltGreen else Color(0x14FFFFFF)
                Surface(
                    modifier = Modifier
                        .testTag("creatine_toggle_button")
                        .clickable { viewModel.toggleCreatine() },
                    color = takenColor,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, if (dailyLog.creatineTaken) VoltGreen else Color(0x1EFFFFFF))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (dailyLog.creatineTaken) Icons.Default.CheckCircle else Icons.Default.AddCircleOutline,
                            contentDescription = "Taken status",
                            tint = if (dailyLog.creatineTaken) Color.Black else Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = if (dailyLog.creatineTaken) "TAKEN" else "LOG 5G",
                            color = if (dailyLog.creatineTaken) Color.Black else Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        // --- QUICK ATHLETIC METRIC TILES ---
        Text(
            text = "LATEST STANDARDS",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                modifier = Modifier.weight(1f),
                color = Color(0x14FFFFFF),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x1EFFFFFF))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("STRENGTH", color = AlertPink, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("${eval.strengthScore.toInt()}%", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Text("Bench Rel: ${String.format(Locale.US, "%.2f", eval.relativeBench)}x", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                }
            }

            Surface(
                modifier = Modifier.weight(1f),
                color = Color(0x14FFFFFF),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x1EFFFFFF))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("EXPLOSION", color = AppleBlue, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("${eval.explosivePowerScore.toInt()}%", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Text("${eval.peakPowerWatts.toInt()} Watts", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                }
            }

            Surface(
                modifier = Modifier.weight(1f),
                color = Color(0x14FFFFFF),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x1EFFFFFF))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("SPEED RATIO", color = VoltGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("${eval.speedPercentile.toInt()}%", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Text("Percentile Std", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                }
            }
        }
    }
}
