package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.FitnessViewModel
import java.util.*

@Composable
fun TrainingScreen(
    viewModel: FitnessViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val userProfile by viewModel.profile.collectAsStateWithLifecycle()
    val perfLog by viewModel.performanceLog.collectAsStateWithLifecycle()
    val eval by viewModel.athleticEvaluation.collectAsStateWithLifecycle()

    // Temporary inputs
    var benchInput by remember(perfLog.bench1RM) { mutableStateOf(perfLog.bench1RM.toString()) }
    var squatInput by remember(perfLog.squat1RM) { mutableStateOf(perfLog.squat1RM.toString()) }
    var deadliftInput by remember(perfLog.deadlift1RM) { mutableStateOf(perfLog.deadlift1RM.toString()) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SleekScreenHeader(
            title = "Training",
            subtitle = "Lifts & Neuromuscular Standards"
        )

        // --- STRENGTH COEFFICIENT HEADER CARD ---
        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Strength Coefficient",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${eval.strengthScore.toInt()}%",
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                
                Icon(
                    imageVector = Icons.Default.FitnessCenter,
                    contentDescription = "Lift",
                    tint = AlertPink,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            AuraNeonProgress(progress = (eval.strengthScore / 100.0).toFloat(), color = AlertPink)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Normalized against Elite-standard athletic formulas adjusted for a ${userProfile.weightKg}kg body mass.",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 10.sp,
                lineHeight = 14.sp
            )
        }

        // --- LIFT PARAMETER FIELDS ---
        Text(
            text = "LOG ONE-REPETITION MAXIMUM (1RM) IN KG",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            // Inputs grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Bench
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Bench Press",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = benchInput,
                        onValueChange = { benchInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 15.sp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AlertPink,
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedContainerColor = Color(0x0CFFFFFF)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("strength_bench_input")
                    )
                }

                // Squat
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Back Squat",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = squatInput,
                        onValueChange = { squatInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 15.sp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AlertPink,
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedContainerColor = Color(0x0CFFFFFF)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("strength_squat_input")
                    )
                }

                // Deadlift
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Deadlift",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = deadliftInput,
                        onValueChange = { deadliftInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 15.sp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AlertPink,
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedContainerColor = Color(0x0CFFFFFF)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("strength_deadlift_input")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            GlassButton(
                text = "LOG POWER LIFTS",
                onClick = {
                    val b = benchInput.toDoubleOrNull() ?: perfLog.bench1RM
                    val s = squatInput.toDoubleOrNull() ?: perfLog.squat1RM
                    val d = deadliftInput.toDoubleOrNull() ?: perfLog.deadlift1RM
                    viewModel.updateStrengthLifts(b, s, d)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("strength_save_button"),
                accentColor = AlertPink
            )
        }

        // --- RELATIVE STANDARD ANALYSIS CARDS ---
        Text(
            text = "ATHLETIC COEFFICIENTS & STANDARDS",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        // Bench standard details
        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("BENCH PRESS ANALYTICS", color = AlertPink, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${String.format(Locale.US, "%.2f", eval.relativeBench)}x Bodyweight",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Absolute 1RM: ${perfLog.bench1RM} kg",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 11.sp
                    )
                }
                
                Surface(
                    color = when(eval.benchLevel) {
                        "Elite" -> AlertPink.copy(alpha = 0.2f)
                        "Advanced" -> AppleBlue.copy(alpha = 0.2f)
                        else -> Color(0x11FFFFFF)
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = eval.benchLevel,
                        color = when(eval.benchLevel) {
                            "Elite" -> AlertPink
                            "Advanced" -> AppleBlue
                            else -> Color.White
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            val percent = (eval.relativeBench / 1.5).coerceIn(0.1, 1.0).toFloat()
            AuraNeonProgress(progress = percent, color = AlertPink)
            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Beginner (0.8x)", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp)
                Text("Elite (1.5x)", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp)
            }
        }

        // Squat standard details
        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("BACK SQUAT ANALYTICS", color = AlertPink, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${String.format(Locale.US, "%.2f", eval.relativeSquat)}x Bodyweight",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Absolute 1RM: ${perfLog.squat1RM} kg",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 11.sp
                    )
                }
                
                Surface(
                    color = when(eval.squatLevel) {
                        "Elite" -> AlertPink.copy(alpha = 0.2f)
                        "Advanced" -> AppleBlue.copy(alpha = 0.2f)
                        else -> Color(0x11FFFFFF)
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = eval.squatLevel,
                        color = when(eval.squatLevel) {
                            "Elite" -> AlertPink
                            "Advanced" -> AppleBlue
                            else -> Color.White
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            val percent = (eval.relativeSquat / 2.2).coerceIn(0.1, 1.0).toFloat()
            AuraNeonProgress(progress = percent, color = AlertPink)
            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Beginner (1.2x)", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp)
                Text("Elite (2.2x)", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp)
            }
        }

        // Deadlift standard details
        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("DEADLIFT ANALYTICS", color = AlertPink, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${String.format(Locale.US, "%.2f", eval.relativeDeadlift)}x Bodyweight",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Absolute 1RM: ${perfLog.deadlift1RM} kg",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 11.sp
                    )
                }
                
                Surface(
                    color = when(eval.deadliftLevel) {
                        "Elite" -> AlertPink.copy(alpha = 0.2f)
                        "Advanced" -> AppleBlue.copy(alpha = 0.2f)
                        else -> Color(0x11FFFFFF)
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = eval.deadliftLevel,
                        color = when(eval.deadliftLevel) {
                            "Elite" -> AlertPink
                            "Advanced" -> AppleBlue
                            else -> Color.White
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            val percent = (eval.relativeDeadlift / 2.5).coerceIn(0.1, 1.0).toFloat()
            AuraNeonProgress(progress = percent, color = AlertPink)
            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Beginner (1.4x)", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp)
                Text("Elite (2.5x)", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp)
            }
        }
    }
}
