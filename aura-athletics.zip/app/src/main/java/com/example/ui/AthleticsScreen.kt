package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Height
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.FitnessViewModel
import java.util.*

@Composable
fun AthleticsScreen(
    viewModel: FitnessViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val perfLog by viewModel.performanceLog.collectAsStateWithLifecycle()
    val eval by viewModel.athleticEvaluation.collectAsStateWithLifecycle()

    // Temporary inputs
    var sprintInput by remember(perfLog.sprintTime) { mutableStateOf(perfLog.sprintTime.toString()) }
    var jumpInput by remember(perfLog.verticalJump) { mutableStateOf(perfLog.verticalJump.toString()) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SleekScreenHeader(
            title = "Athletics",
            subtitle = "Speed & Power Mechanics"
        )

        // --- ATHLETICS SCORE OVERVIEW ---
        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Kinetic Efficiency",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    // Combination of Speed, Jump, and Power outputs
                    val kineticAvg = (eval.explosivePowerScore + eval.speedPercentile + eval.jumpIndex) / 3.0
                    Text(
                        text = "${kineticAvg.toInt()}%",
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = "Bolt",
                    tint = AppleBlue,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            val percent = ((eval.explosivePowerScore + eval.speedPercentile + eval.jumpIndex) / 300.0).toFloat()
            AuraNeonProgress(progress = percent, color = AppleBlue)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Aggregates raw biomechanical velocity targets and leap-propulsion indices.",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 10.sp,
                lineHeight = 14.sp
            )
        }

        // --- ATHLETIC RECORDS LOGGING FORM ---
        Text(
            text = "LOG ATHLETIC COMBINE METRICS",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Sprint Time input
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.DirectionsRun, contentDescription = null, tint = AppleBlue, modifier = Modifier.size(14.dp))
                        Text(
                            text = "30m Sprint (s)",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = sprintInput,
                        onValueChange = { sprintInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 15.sp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AppleBlue,
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedContainerColor = Color(0x0CFFFFFF)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sprint_time_input")
                    )
                }

                // Vertical jump input
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Height, contentDescription = null, tint = AppleBlue, modifier = Modifier.size(14.dp))
                        Text(
                            text = "Vertical Jump (cm)",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = jumpInput,
                        onValueChange = { jumpInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 15.sp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AppleBlue,
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedContainerColor = Color(0x0CFFFFFF)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("vertical_jump_input")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            GlassButton(
                text = "SAVE COMBINE MEASUREMENTS",
                onClick = {
                    val sp = sprintInput.toDoubleOrNull() ?: perfLog.sprintTime
                    val jp = jumpInput.toDoubleOrNull() ?: perfLog.verticalJump
                    viewModel.updateAthleticsMetrics(sp, jp)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("athletics_save_button"),
                accentColor = AppleBlue
            )
        }

        // --- ATHLETIC COEFFICIENTS & STANDARDS ---
        Text(
            text = "BIOMECHANICAL VELOCITY & EXPLOSION",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        // 1. Sprint Velocity standard
        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("30M SPRINT VELOCITY", color = AppleBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${perfLog.sprintTime} seconds",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Velocity score: ${eval.speedPercentile.toInt()}% of athlete norms",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 11.sp
                    )
                }

                Surface(
                    color = when {
                        eval.speedPercentile >= 85.0 -> AlertPink.copy(alpha = 0.20f)
                        eval.speedPercentile >= 72.0 -> AppleBlue.copy(alpha = 0.20f)
                        else -> Color(0x11FFFFFF)
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    val label = when {
                        eval.speedPercentile >= 85.0 -> "PRO-ELITE"
                        eval.speedPercentile >= 72.0 -> "ATHLETE"
                        eval.speedPercentile >= 55.0 -> "ADVANCED"
                        eval.speedPercentile >= 35.0 -> "INTERMEDIATE"
                        else -> "BEGINNER"
                    }
                    Text(
                        text = label,
                        color = when {
                            eval.speedPercentile >= 85.0 -> AlertPink
                            eval.speedPercentile >= 72.0 -> AppleBlue
                            else -> Color.White
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        letterSpacing = 1.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            AuraNeonProgress(progress = (eval.speedPercentile / 100.0).toFloat(), color = AppleBlue)
            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Slow (5.5s)", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp)
                Text("Elite (3.8s)", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp)
            }
        }

        // 2. Saylor Peak Power standard
        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("SAYLOR peak POWER OUTPUT", color = AppleBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${eval.peakPowerWatts.toInt()} Watts",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Propulsion energy calculated from leap kinetics",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 11.sp
                    )
                }

                Surface(
                    color = VoltGreen.copy(alpha = 0.20f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "${eval.explosivePowerScore.toInt()}% FORCE",
                        color = VoltGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            AuraNeonProgress(progress = (eval.explosivePowerScore / 100).toFloat(), color = VoltGreen)
            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Low (0cm)", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp)
                Text("Elite Jump (80cm)", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp)
            }
        }

        // 3. Jump Performance Index standard
        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("JUMP PERFORMANCE INDEX (JPI)", color = AppleBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Leap Standard: ${perfLog.verticalJump} cm",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Score based on plyometric explosive height limits",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 11.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            AuraNeonProgress(progress = (eval.jumpIndex / 100.0).toFloat(), color = AppleBlue)
            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Baseline", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp)
                Text("High Plyometric Standard", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp)
            }
        }
    }
}
