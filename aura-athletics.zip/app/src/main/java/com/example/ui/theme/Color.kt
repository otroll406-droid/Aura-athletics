package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Obsidian Space Canvas
val SpaceBlack = Color(0xFF050505)
val SpaceCardBg = Color(0x14FFFFFF) // 8% glass backing
val SpaceCardBorder = Color(0x1EFFFFFF) // 12% translucent border

// Apple Fitness Liquid Accents
val AppleBlue = Color(0xFF007AFF) // Premium iOS Accent Blue
val VoltGreen = Color(0xFF30D158) // Beautiful premium Green
val AlertPink = Color(0xFFFF2D55) // Muscle/Strength warning pink
val WarmOrange = Color(0xFFFF9F0A) // Creatine Tracker orange
val DeepOrange = Color(0xFFFF3B30) // Primary alert Red

val TextPrimary = Color(0xFFF5F5F7) // Pure sleek off-white text
val TextSecondary = Color(0xFF8E8E93)
val TextMuted = Color(0xFF48484A)

// Secondary details
val SlateBlue = Color(0xFF1C1C1E)
val IceWhite = Color(0xFFF2F2F7)
