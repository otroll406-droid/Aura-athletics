package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.FitnessViewModel

@Composable
fun NutritionScreen(
    viewModel: FitnessViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val userProfile by viewModel.profile.collectAsStateWithLifecycle()
    val nutrition by viewModel.nutritionMetrics.collectAsStateWithLifecycle()

    // Temporary input states initialized with current profile
    var weightInput by remember(userProfile.weightKg) { mutableStateOf(userProfile.weightKg.toString()) }
    var heightInput by remember(userProfile.heightCm) { mutableStateOf(userProfile.heightCm.toString()) }
    var ageInput by remember(userProfile.age) { mutableStateOf(userProfile.age.toString()) }
    var selectedGender by remember(userProfile.gender) { mutableStateOf(userProfile.gender) }
    var selectedActivity by remember(userProfile.activityLevel) { mutableStateOf(userProfile.activityLevel) }
    var selectedGoal by remember(userProfile.goal) { mutableStateOf(userProfile.goal) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SleekScreenHeader(
            title = "Nutrition",
            subtitle = "Metabolic Tracker & Balance"
        )

        // --- CURRENT GOAL & MACROS OUTPUT GLASS CARD ---
        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Target Calories",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${nutrition.dailyCalories} kcal",
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                
                Surface(
                    color = VoltGreen.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = selectedGoal.uppercase(),
                        color = VoltGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Progress Indicators
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Protein
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Protein (${nutrition.proteinRatio}g/kg)",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${nutrition.proteinG} g",
                            color = VoltGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    AuraNeonProgress(progress = 0.8f, color = VoltGreen)
                }

                // Fats
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Fats (${nutrition.fatRatio}g/kg)",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${nutrition.fatG} g",
                            color = WarmOrange,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    AuraNeonProgress(progress = 0.5f, color = WarmOrange)
                }

                // Carbs
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Carbohydrates (Residual 에너지)",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${nutrition.carbG} g",
                            color = AppleBlue,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    AuraNeonProgress(progress = 0.65f, color = AppleBlue)
                }
            }
        }

        // --- PROFILE EDIT INPUTS ---
        Text(
            text = "BIOMETRIC INPUTS",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        AuraGlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Weight input
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Weight (kg)",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = weightInput,
                        onValueChange = { weightInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 15.sp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VoltGreen,
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedContainerColor = Color(0x0CFFFFFF),
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("nutrition_weight_input")
                    )
                }

                // Height input
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Height (cm)",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = heightInput,
                        onValueChange = { heightInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 15.sp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VoltGreen,
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedContainerColor = Color(0x0CFFFFFF),
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("nutrition_height_input")
                    )
                }

                // Age input
                Column(modifier = Modifier.weight(0.8f)) {
                    Text(
                        text = "Age",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = ageInput,
                        onValueChange = { ageInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 15.sp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VoltGreen,
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedContainerColor = Color(0x0CFFFFFF),
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("nutrition_age_input")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Gender select (Visual chips)
            Text(
                text = "Gender",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Male", "Female").forEach { g ->
                    val isSelected = selectedGender.equals(g, ignoreCase = true)
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedGender = g },
                        color = if (isSelected) VoltGreen else Color(0x11FFFFFF),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (isSelected) VoltGreen else Color(0x22FFFFFF))
                    ) {
                        Text(
                            text = g.uppercase(),
                            color = if (isSelected) Color.Black else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Goal select (Visual chips)
            Text(
                text = "Primary Athletic Goal",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("Cut", "Maintenance", "Bulk").forEach { goal ->
                    val isSelected = selectedGoal.equals(goal, ignoreCase = true)
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedGoal = goal },
                        color = if (isSelected) AppleBlue else Color(0x11FFFFFF),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (isSelected) AppleBlue else Color(0x22FFFFFF))
                    ) {
                        Text(
                            text = goal.uppercase(),
                            color = if (isSelected) Color.Black else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Activity level select (Visual vertical stack)
            Text(
                text = "Activity Multiplier",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            
            val activities = listOf(
                "Sedentary" to "Base BMR x 1.2 (Desk job, zero sport)",
                "Lightly Active" to "Base BMR x 1.375 (1-3 hrs light training)",
                "Moderately Active" to "Base BMR x 1.55 (3-5 hrs intense sport)",
                "Active" to "Base BMR x 1.725 (Daily high-intensity sessions)",
                "Very Active" to "Base BMR x 1.9 (2x daily pro-athletic training)"
            )

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                activities.forEach { (name, label) ->
                    val isSelected = selectedActivity.equals(name, ignoreCase = true)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) Color(0x2232D74B) else Color(0x11FFFFFF))
                            .border(1.dp, if (isSelected) VoltGreen else Color(0x1AFFFFFF), RoundedCornerShape(10.dp))
                            .clickable { selectedActivity = name }
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = name,
                                color = if (isSelected) VoltGreen else Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = label,
                                color = Color.White.copy(alpha = 0.5f),
                                fontSize = 10.sp
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = VoltGreen,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Save buttons
            GlassButton(
                text = "CALCULATE AND UPDATE PROFILE",
                onClick = {
                    val w = weightInput.toDoubleOrNull() ?: userProfile.weightKg
                    val h = heightInput.toDoubleOrNull() ?: userProfile.heightCm
                    val a = ageInput.toIntOrNull() ?: userProfile.age
                    viewModel.updateProfile(
                        weight = w,
                        height = h,
                        age = a,
                        gender = selectedGender,
                        activityLevel = selectedActivity,
                        goal = selectedGoal
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("nutrition_save_button"),
                accentColor = VoltGreen
            )
        }
    }
}
