package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalDining
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.AppleBlue
import com.example.viewmodel.FitnessViewModel
import com.example.viewmodel.FitnessViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                val factory = FitnessViewModelFactory(context)
                val viewModel: FitnessViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)

                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            containerColor = Color(0xF2050505),
                            tonalElevation = 8.dp
                        ) {
                            val items = listOf(
                                NavigationItem("dashboard", "Dashboard", Icons.Default.Dashboard),
                                NavigationItem("nutrition", "Nutrition", Icons.Default.LocalDining),
                                NavigationItem("training", "Training", Icons.Default.FitnessCenter),
                                NavigationItem("athletics", "Athletics", Icons.Default.Bolt),
                                NavigationItem("profile", "Profile", Icons.Default.Person)
                            )

                            items.forEach { item ->
                                val active = currentRoute == item.route
                                NavigationBarItem(
                                    selected = active,
                                    onClick = {
                                        navController.navigate(item.route) {
                                            popUpTo("dashboard") { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = item.icon,
                                            contentDescription = item.title,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = item.title,
                                            fontSize = 11.sp,
                                            fontWeight = if (active) androidx.compose.ui.text.font.FontWeight.Black else androidx.compose.ui.text.font.FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = AppleBlue,
                                        selectedTextColor = AppleBlue,
                                        unselectedIconColor = Color.White.copy(alpha = 0.4f),
                                        unselectedTextColor = Color.White.copy(alpha = 0.4f),
                                        indicatorColor = Color(0x22FFFFFF)
                                    ),
                                    modifier = Modifier.testTag("nav_item_${item.route}")
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "dashboard",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("dashboard") {
                            DashboardScreen(viewModel = viewModel)
                        }
                        composable("nutrition") {
                            NutritionScreen(viewModel = viewModel)
                        }
                        composable("training") {
                            TrainingScreen(viewModel = viewModel)
                        }
                        composable("athletics") {
                            AthleticsScreen(viewModel = viewModel)
                        }
                        composable("profile") {
                            ProfileScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

data class NavigationItem(
    val route: String,
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)
